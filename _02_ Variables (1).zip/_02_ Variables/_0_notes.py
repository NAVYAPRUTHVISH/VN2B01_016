x = (10+25-30)


'''
write operation:
-----------------------------------------

step -1 : Load the statement

step-2: Execution starts from R.H.S = L.H.S

step-3 : In R.H.S ,finds the type of data like int, float, boolean, str

step-4 : If any expression , it performs the operation.final value, 
it converts final value into binary format

step-5 : Binary value will be alloacted some memory

step-6 : Memory address will be reffered to varible


'''

print(x)
print(id(x))

y = True
print(id(y))


z = "str"
print(id(z))


print(x)  # read operation retrieving



x = 10
y = 10
z = 10

'''
Rules/ validations:
1. _ or letters (lowercase)
2. Dont use numbers
3. Dont use keywords ,special symbols
'''

